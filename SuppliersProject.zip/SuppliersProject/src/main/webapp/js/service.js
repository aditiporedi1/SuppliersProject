'use strict';

angular.module("suppliersApp.services", ["ngResource"])
    .factory("Todo", function($resource){
    	return $resource('rest/todos/:id', {id:'@id'}, {
    		update: {
                method: 'PUT'
              }
    	});
    });